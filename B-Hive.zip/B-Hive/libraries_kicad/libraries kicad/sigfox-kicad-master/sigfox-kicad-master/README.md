# sigfox-kicad
Footprints of sigfox modules and breakout boards
